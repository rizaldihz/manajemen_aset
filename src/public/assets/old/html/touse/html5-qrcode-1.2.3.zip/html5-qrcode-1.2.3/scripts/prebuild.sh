## Prebuild script
echo 'Initiating pre-build sequence'

echo > minified/html5-qrcode.min.js
echo 'html5-qrcode.min.js truncated!'
