# Generated code, do not modify manually.

 - All files in this directory are transpiled from their source files in [src](../src).
 - The files are created using [babeljs.io](https://babeljs.io).
 - Generated files should be supported in all major browsers.