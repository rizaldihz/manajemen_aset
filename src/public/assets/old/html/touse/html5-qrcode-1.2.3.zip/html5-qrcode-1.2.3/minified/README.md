# Generated code, do not modify manually.

 - All files in this directory are minified from source code in the project hosted at [src](../src).
 - Generated files should be supported in all major browsers.